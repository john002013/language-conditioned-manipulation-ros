#!/usr/bin/env python3
"""
Improved Pick and Place with better alignment and high lift
Usage:
ros2 run pymoveit2 pick_and_place1.py --ros-args -p target_color:=R
ros2 run pymoveit2 pick_and_place1.py --ros-args -p target_color:=G
ros2 run pymoveit2 pick_and_place1.py --ros-args -p target_color:=B
"""

from threading import Thread
import rclpy
from rclpy.node import Node
from rclpy.callback_groups import ReentrantCallbackGroup
from std_msgs.msg import String

from pymoveit2 import MoveIt2, GripperInterface
from pymoveit2.robots import panda

import math
import time


class PickAndPlace(Node):
    def __init__(self):
        super().__init__("pick_and_place")

        # Parameters
        self.declare_parameter("target_color", "R")
        self.target_color = self.get_parameter("target_color").value.upper()

        # Flags
        self.already_moved = False
        self.target_coords = None
        self.coord_buffer = []  # For averaging coordinates

        self.callback_group = ReentrantCallbackGroup()

        # ========================================
        # TUNING PARAMETERS - Adjust for better picking
        # ========================================
        self.z_offset_above = 0.55        # Height above object (LOWERED from 0.60)
        self.z_approach = 0.35            # Descend distance (INCREASED from 0.31 - go deeper)
        self.gripper_wait_time = 0.3      # Wait after gripper operations (INCREASED)
        self.pre_grasp_wait = 0.4         # Pause before closing (INCREASED)
        self.post_grasp_wait = 0.2        # Pause after closing (INCREASED)
        self.lift_height = 0.20           # Initial lift after grasp (INCREASED)
        self.safe_lift_height = 0.40      # High lift before moving to drop (NEW - VERY HIGH)
        self.coordinate_samples = 3       # Number of samples to average (NEW)

        # Wait for controllers to be ready
        self.get_logger().info("Waiting for controllers to initialize...")
        time.sleep(3)

        # Arm MoveIt2 interface
        self.moveit2 = MoveIt2(
            node=self,
            joint_names=panda.joint_names(),
            base_link_name=panda.base_link_name(),
            end_effector_name=panda.end_effector_name(),
            group_name=panda.MOVE_GROUP_ARM,
            callback_group=self.callback_group,
        )

        # Slower for better control
        self.moveit2.max_velocity = 0.25      # REDUCED from 0.2
        self.moveit2.max_acceleration = 0.25  # REDUCED from 0.2

        # Gripper interface
        self.gripper = GripperInterface(
            node=self,
            gripper_joint_names=panda.gripper_joint_names(),
            open_gripper_joint_positions=panda.OPEN_GRIPPER_JOINT_POSITIONS,
            closed_gripper_joint_positions=panda.CLOSED_GRIPPER_JOINT_POSITIONS,
            gripper_group_name=panda.MOVE_GROUP_GRIPPER,
            callback_group=self.callback_group,
            gripper_command_action_name="gripper_action_controller/gripper_cmd",
        )

        # Subscriber
        self.sub = self.create_subscription(
            String, "/color_coordinates", self.coords_callback, 10
        )
        self.get_logger().info(f"Waiting for {self.target_color} from /color_coordinates...")

        # Predefined joint positions (in radians)
        self.start_joints = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, math.radians(-125.0)]
        self.home_joints  = [0.0, 0.0, 0.0, math.radians(-90.0), 0.0, math.radians(92.0), math.radians(50.0)]
        self.drop_joints  = [math.radians(-155.0), math.radians(30.0), math.radians(-20.0),
                             math.radians(-124.0), math.radians(44.0), math.radians(163.0), math.radians(7.0)]

        # Wait for joint states to be available
        self.get_logger().info("Waiting for joint states...")
        timeout = 30
        start_time = time.time()
        while not self.moveit2.joint_state and (time.time() - start_time) < timeout:
            self.get_logger().warn("Joint states not available yet...")
            time.sleep(0.5)
        
        if not self.moveit2.joint_state:
            self.get_logger().error("Joint states never became available!")
            return

        # Move to start joint configuration
        self.get_logger().info("Moving to start position...")
        self.moveit2.move_to_configuration(self.start_joints)
        self.moveit2.wait_until_executed()
        self.get_logger().info(f"Ready! Waiting for {self.target_color} object...")

    def coords_callback(self, msg):
        """Collect multiple coordinate samples and average them for better accuracy"""
        if self.already_moved:
            return

        try:
            color_id, x, y, z = msg.data.split(",")
            color_id = color_id.strip().upper()

            if color_id == self.target_color:
                # Store coordinate sample
                coords = [float(x), float(y), float(z)]
                self.coord_buffer.append(coords)
                
                # Once we have enough samples, average them and lock
                if len(self.coord_buffer) >= self.coordinate_samples:
                    # Average the coordinates for better accuracy
                    avg_x = sum(c[0] for c in self.coord_buffer) / len(self.coord_buffer)
                    avg_y = sum(c[1] for c in self.coord_buffer) / len(self.coord_buffer)
                    avg_z = sum(c[2] for c in self.coord_buffer) / len(self.coord_buffer)
                    
                    self.target_coords = [avg_x, avg_y, avg_z]
                    self.get_logger().info(
                        f"Target {self.target_color} locked at (averaged): "
                        f"[{self.target_coords[0]:.3f}, {self.target_coords[1]:.3f}, {self.target_coords[2]:.3f}]"
                    )
                    self.already_moved = True

                    # Execute pick and place sequence
                    success = self.execute_pick_and_place()
                    
                    if success:
                        self.get_logger().info("Pick-and-place sequence complete!")
                    else:
                        self.get_logger().error("Pick-and-place sequence failed!")
                    
                    rclpy.shutdown()
                else:
                    self.get_logger().info(
                        f"Collecting samples... ({len(self.coord_buffer)}/{self.coordinate_samples})"
                    )

        except Exception as e:
            self.get_logger().error(f"Error parsing /color_coordinates: {e}")

    def execute_pick_and_place(self):
        """Execute the pick and place sequence with better alignment and high lift"""
        try:
            # Calculate positions based on detected coordinates
            pick_position = [
                self.target_coords[0],
                self.target_coords[1],
                self.target_coords[2] - self.z_offset_above
            ]
            approach_position = [
                pick_position[0],
                pick_position[1],
                pick_position[2] - self.z_approach
            ]
            quat_xyzw = [0.0, 1.0, 0.0, 0.0]  # Gripper pointing down

            # ===== PICK SEQUENCE =====

            # Step 1: Move to home joint configuration
            self.get_logger().info("Step 1: Moving to home position...")
            self.moveit2.move_to_configuration(self.home_joints)
            self.moveit2.wait_until_executed()
            time.sleep(0.3)

            # Step 2: Move above target (Cartesian)
            self.get_logger().info(
                f"Step 2: Moving above target at "
                f"({pick_position[0]:.3f}, {pick_position[1]:.3f}, {pick_position[2]:.3f})"
            )
            self.moveit2.move_to_pose(position=pick_position, quat_xyzw=quat_xyzw)
            self.moveit2.wait_until_executed()
            time.sleep(0.3)

            # Step 3: Open gripper WIDE
            self.get_logger().info("Step 3: Opening gripper wide...")
            self.gripper.open()
            self.gripper.wait_until_executed()
            time.sleep(self.gripper_wait_time)

            # Step 4: Move down to approach object (STRAIGHT DOWN)
            self.get_logger().info(
                f"Step 4: Descending {self.z_approach}m to "
                f"({approach_position[0]:.3f}, {approach_position[1]:.3f}, {approach_position[2]:.3f})"
            )
            self.moveit2.move_to_pose(
                position=approach_position,
                quat_xyzw=quat_xyzw,
                cartesian=True  # Forces straight-line motion
            )
            self.moveit2.wait_until_executed()
            time.sleep(self.pre_grasp_wait)

            # Step 5: Close gripper firmly
            self.get_logger().info("Step 5: Closing gripper to grasp...")
            self.gripper.close()
            self.gripper.wait_until_executed()
            time.sleep(self.post_grasp_wait)

            # Step 6: Small lift to verify grip
            self.get_logger().info(f"Step 6: Small lift ({self.lift_height}m) to verify grip...")
            lift_position = [
                approach_position[0],
                approach_position[1],
                approach_position[2] + self.lift_height
            ]
            self.moveit2.move_to_pose(
                position=lift_position,
                quat_xyzw=quat_xyzw,
                cartesian=True  # Straight up
            )
            self.moveit2.wait_until_executed()
            time.sleep(0.3)

            # Step 7: HIGH LIFT for safe transport
            self.get_logger().info(f"Step 7: HIGH LIFT ({self.safe_lift_height}m) for transport...")
            high_lift_position = [
                approach_position[0],
                approach_position[1],
                approach_position[2] + self.safe_lift_height
            ]
            self.moveit2.move_to_pose(
                position=high_lift_position,
                quat_xyzw=quat_xyzw,
                cartesian=True  # Straight up
            )
            self.moveit2.wait_until_executed()
            time.sleep(0.3)

            # Step 8: Move to home joint configuration
            self.get_logger().info("Step 8: Moving to home with object (high in air)...")
            self.moveit2.move_to_configuration(self.home_joints)
            self.moveit2.wait_until_executed()
            time.sleep(0.3)

            # ===== PLACE SEQUENCE =====

            # Step 9: Move to drop joint configuration
            self.get_logger().info("Step 9: Moving to drop location...")
            self.moveit2.move_to_configuration(self.drop_joints)
            self.moveit2.wait_until_executed()
            time.sleep(0.3)

            # Step 10: Open gripper to release into bucket
            self.get_logger().info("Step 10: Releasing object into bucket...")
            self.gripper.open()
            self.gripper.wait_until_executed()
            time.sleep(self.gripper_wait_time)

            # Step 11: Close gripper
            self.get_logger().info("Step 11: Closing gripper...")
            self.gripper.close()
            self.gripper.wait_until_executed()
            time.sleep(0.3)

            # Step 12: Return to start joint configuration
            self.get_logger().info("Step 12: Returning to start position...")
            self.moveit2.move_to_configuration(self.start_joints)
            self.moveit2.wait_until_executed()

            return True

        except Exception as e:
            self.get_logger().error(f"Pick-and-place failed: {e}")
            return False


def main():
    rclpy.init()
    node = PickAndPlace()

    executor = rclpy.executors.MultiThreadedExecutor(2)
    executor.add_node(node)
    executor_thread = Thread(target=executor.spin, daemon=True)
    executor_thread.start()

    try:
        executor_thread.join()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()