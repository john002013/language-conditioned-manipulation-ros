#!/usr/bin/env python3
"""
Robot Control Agent - Scheduling Agent Format
Continuous loop for natural language robot control

Usage:
    python3 robot_agent.py
"""

from threading import Thread
import rclpy
import time
from pydantic import BaseModel
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import PydanticOutputParser
from langchain.agents import create_tool_calling_agent, AgentExecutor
from robot_controller import RobotController
from tool import all_tools, set_robot_controller


# ============================================================================
# PYDANTIC MODEL FOR STRUCTURED OUTPUT (Optional)
# ============================================================================

class RobotResponse(BaseModel):
    """Structure for robot responses"""
    action: str
    status: str
    details: str

# ============================================================================
# LLM CONFIGURATION
# ============================================================================

llm = ChatOpenAI(
    openai_api_key="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",
    base_url="https://models.github.ai/inference",
    model_name="openai/gpt-4o",
    temperature=0.1
)


# ============================================================================
# AGENT CREATION
# ============================================================================

parser = PydanticOutputParser(pydantic_object=RobotResponse)

System_prompt = ChatPromptTemplate.from_messages([
    (
        "system",
        """You are a robot control assistant for a pick-and-place robotic arm.

AVAILABLE TOOLS:
- pick_red: Pick up red object
- pick_green: Pick up green object  
- pick_blue: Pick up blue object
- place_object: Place held object in bucket
- go_home: Move to home position
- go_start: Move to start position
- open_gripper: Open the gripper
- close_gripper: Close the gripper
- stop_robot: Emergency stop
- reset_robot: Reset to initial state
- check_status: Check robot status
- get_detected_colors: List the current detected objects
- save_robot_log: Save operation log

RULES:
1. Always use the SPECIFIC color pick tools (pick_red, pick_green, pick_blue)
2. Robot can only hold ONE object at a time
3. Before picking, you can check what's detected with get_detected_colors
4. Always call the appropriate tool - never just explain what you would do
5. If user says "stop" or "emergency", immediately call stop_robot
6. Confirm actions after tools complete
7. When I asked about what you see just answerwith the current detected objects

EXAMPLES:

User: "Pick the red block"
You: I'll pick up the red object now.
[calls pick_red tool]
Response: "Red object has been picked successfully"

User: "What can you see?"
You: Let me check the detected objects.
[calls get_detected_colors tool]
Response: "I can see: Red at (0.6, 0.2, 1.1), Green at (0.55, 0.18, 1.09)"

User: "Place it"
You: I'll place the object in the bucket.
[calls place_object tool]
Response: "Object placed at desired location successfully"

Always be concise and action-oriented. Call tools, don't just talk about them.
"""
    ),
    ("placeholder", "{chat_history}"),
    ("human", "{query}"),
    ("placeholder", "{agent_scratchpad}"),
]).partial(format_instructions=parser.get_format_instructions())


# ============================================================================
# CREATE AGENT
# ============================================================================

def create_robot_agent():
    """Create the robot control agent"""
    agent = create_tool_calling_agent(
        llm=llm,
        prompt=System_prompt,
        tools=all_tools
    )
    
    robot_agent = AgentExecutor(
        agent=agent,
        tools=all_tools,
        verbose=True,
        handle_parsing_errors=True,
        max_iterations=5
    )
    
    return robot_agent


# ============================================================================
# INTERACTIVE LOOP
# ============================================================================

def run_agent_loop(robot_agent):
    """Continuous interactive loop for robot control"""
    
    print("\n" + "="*70)
    print("ROBOT CONTROL AGENT (BUILT BY BABALOLA JOHN) - READY FOR COMMANDS!")
    print("="*70)
    print("Type 'help' for assistance, 'clear' to reset chat history, or 'quit' to exit.")
    print("="*70 + "\n")
    
    # Chat history for context
    chat_history = []
    
    while rclpy.ok():
        try:
            # Get user input
            query = input("You: ").strip()
            
            # Exit commands
            if query.lower() in ['shutdown', 'exit', 'q', 'bye', 'goodbye']:
                print("\nShutting down robot agent...")
                break
            
            # Skip empty input
            if not query:
                continue
            
            # Help command
            if query.lower() in ['help', '?']:
                print("\nHELP:")
                print("  Just tell me what you want the robot to do!")
                print("  Examples:")
                print("    - 'Pick the green object'")
                print("    - 'What colors do you see?'")
                print("    - 'Place it down'\n")
                continue
            
            # Clear history
            if query.lower() in ['clear', 'reset history']:
                chat_history = []
                print("\n Chat history cleared!\n")
                continue
            
            # Execute agent
            print()  # Blank line
            
            try:
                raw_response = robot_agent.invoke({
                    "query": query,
                    "chat_history": chat_history
                })
                
                response = raw_response.get("output")
                print(f"\n Robot: {response}\n")
                
                # Update chat history
                chat_history.append({"role": "user", "content": query})
                chat_history.append({"role": "assistant", "content": response})
                
                # Keep last 20 messages
                if len(chat_history) > 20:
                    chat_history = chat_history[-20:]
                    
            except Exception as e:
                print(f"\n Error: {e}")
                print("Please try rephrasing your command.\n")
            
        except KeyboardInterrupt:
            print("\n\n Shutting down...")
            break
        except Exception as e:
            print(f"\n Unexpected error: {e}\n")


# ============================================================================
# MAIN ENTRY POINT
# ============================================================================

def main():
    """Main function - orchestrates robot system startup"""
    
    print("="*70)
    print(" INITIALIZING ROBOT CONTROL SYSTEM")
    print("="*70)
    
    # Step 1: Initialize ROS2
    print("\n[1/5] Initializing ROS2 Please Wait...")
    rclpy.init()
    print("     JOhn's ROS2 engine initialized suceessfully")
    
    # Step 2: Create robot controller
    print("\n[2/5] Creating robot controller...")
    robot_controller = RobotController()
    print("      Robot controller created")
    
    # Step 3: Connect tools to controller
    print("\n[3/5]  Connecting tools to controller wait a minute...")
    set_robot_controller(robot_controller)
    print("      All available tools have been  connected successfully")
    
    # Step 4: Start ROS2 executor
    print("\n[4/5]   Starting ROS2 executor...")
    executor = rclpy.executors.MultiThreadedExecutor(2)
    executor.add_node(robot_controller)
    executor_thread = Thread(target=executor.spin, daemon=True)
    executor_thread.start()
    print("      ROS2 executor running")
    
    # Step 5: Wait for vision system
    print("\n[5/5] Waiting for vision system...")
    time.sleep(3)
    print("     Type-shii the system is ready!")
    
    # Create agent
    print("\n Initializing Robot's AI agent Please Wait...")
    try:
        robot_agent = create_robot_agent()
        print("   Robot's AI agent ready!")
    except Exception as e:
        print(f"    Failed to create agent: {e}")
        rclpy.shutdown()
        return
    
    # Run continuous loop
    try:
        run_agent_loop(robot_agent)
    except KeyboardInterrupt:
        pass
    finally:
        print("\n Cleaning up...")
        rclpy.shutdown()
        print("System has been shutdown completely.")


if __name__ == "__main__":
    main()