#!/usr/bin/env python3
"""
ROS2 Robot Controller using PyMoveIt2 for AI integration
Handles all robot movement and gripper operations with enhanced methods
"""

import rclpy
from rclpy.node import Node
from rclpy.callback_groups import ReentrantCallbackGroup
from std_msgs.msg import String

from pymoveit2 import MoveIt2, GripperInterface
from pymoveit2.robots import panda

import math
import time


class RobotController(Node):
    """ROS2 node that handles robot control operations"""
    
    def __init__(self):
        super().__init__("robot_controller")
        
        self.target_coords = None
        self.latest_coords = {}  # Store latest coords for each color
        self.is_holding_object = False
        self.last_picked_color = None
        self.motion_stopped = False
        
        self.callback_group = ReentrantCallbackGroup()
        
        # === TUNING PARAMETERS ===
        self.z_offset_above = 0.55        # Height above object (LOWERED from 0.60)
        self.z_approach = 0.35            # Descend distance (INCREASED from 0.31 - go deeper)
        self.gripper_wait_time = 0.3      # Wait after gripper operations (INCREASED)
        self.pre_grasp_wait = 0.4         # Pause before closing (INCREASED)
        self.post_grasp_wait = 0.2        # Pause after closing (INCREASED)
        self.lift_height = 0.20           # Initial lift after grasp (INCREASED)
        self.safe_lift_height = 0.40      # High lift before moving to drop (NEW - VERY HIGH)
        self.coordinate_samples = 3       # Number of samples to average (NEW)

        
        # Wait for controllers to be ready
        self.get_logger().info("Waiting for controllers to initialize...")
        time.sleep(3)
        
        # Arm MoveIt2 interface
        self.moveit2 = MoveIt2(
            node=self,
            joint_names=panda.joint_names(),
            base_link_name=panda.base_link_name(),
            end_effector_name=panda.end_effector_name(),
            group_name=panda.MOVE_GROUP_ARM,
            callback_group=self.callback_group,
        )
        
        # Set velocity and acceleration
        self.moveit2.max_velocity = 0.25
        self.moveit2.max_acceleration = 0.25
        
        # Gripper interface
        self.gripper = GripperInterface(
            node=self,
            gripper_joint_names=panda.gripper_joint_names(),
            open_gripper_joint_positions=panda.OPEN_GRIPPER_JOINT_POSITIONS,
            closed_gripper_joint_positions=panda.CLOSED_GRIPPER_JOINT_POSITIONS,
            gripper_group_name=panda.MOVE_GROUP_GRIPPER,
            callback_group=self.callback_group,
            gripper_command_action_name="gripper_action_controller/gripper_cmd",
        )
        
        # Subscriber for color coordinates
        self.sub = self.create_subscription(
            String, "/color_coordinates", self.coords_callback, 10
        )
        
        # Predefined joint positions (in radians)
        self.start_joints = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, math.radians(-125.0)]
        self.home_joints = [0.0, 0.0, 0.0, math.radians(-90.0), 0.0, math.radians(92.0), math.radians(50.0)]
        self.drop_joints = [
            math.radians(-155.0), math.radians(30.0), math.radians(-20.0),
            math.radians(-124.0), math.radians(44.0), math.radians(163.0), math.radians(7.0)
        ]

        self.wave_pose_1 = [
            math.radians(45.0), math.radians(-30.0), math.radians(0.0),
                           math.radians(-90.0), math.radians(0.0), math.radians(120.0), math.radians(0.0)
        ]
        
        self.wave_pose_2 = [
            math.radians(45.0), math.radians(-30.0), math.radians(0.0),
                           math.radians(-90.0), math.radians(0.0), math.radians(100.0), math.radians(0.0)
    ]
        
        self.dab_pose = [
            math.radians(-90.0), math.radians(-45.0), math.radians(90.0),
                        math.radians(-45.0), math.radians(0.0), math.radians(90.0), math.radians(45.0)
        ]

        self.t_pose = [
            math.radians(0.0), math.radians(-90.0), math.radians(0.0),
            math.radians(-90.0), math.radians(0.0), math.radians(90.0), math.radians(0.0)
        ]

        self.thinking_pose = [
            math.radians(30.0), math.radians(-60.0), math.radians(30.0),
            math.radians(-120.0), math.radians(45.0), math.radians(90.0), math.radians(0.0)
        ]

        self.salute_pose = [
            math.radians(60.0), math.radians(-45.0), math.radians(-30.0),
            math.radians(-90.0), math.radians(90.0), math.radians(120.0), math.radians(0.0)
        ]

        self.victory_pose = [
            math.radians(0.0), math.radians(-120.0), math.radians(60.0),
            math.radians(-60.0), math.radians(0.0), math.radians(150.0), math.radians(0.0)
        ]


        # Wait for joint states
        self.get_logger().info("Waiting for joint states...")
        timeout = 30
        start_time = time.time()
        while not self.moveit2.joint_state and (time.time() - start_time) < timeout:
            self.get_logger().warn("Joint states not available yet...")
            time.sleep(0.5)
        
        if not self.moveit2.joint_state:
            self.get_logger().error("Joint states never became available!")
            return
        
        # Move to start position
        self.get_logger().info("Moving to start position...")
        self.moveit2.move_to_configuration(self.start_joints)
        self.moveit2.wait_until_executed()
        self.get_logger().info("Robot initialized and ready!")
    
    def coords_callback(self, msg):
        """Update latest coordinates for each color"""
        try:
            color_id, x, y, z = msg.data.split(",")
            color_id = color_id.strip().upper()
            self.latest_coords[color_id] = [float(x), float(y), float(z)]
        except Exception as e:
            self.get_logger().error(f"Error parsing coordinates: {e}")
    
    def pick_object(self, color: str) -> str:
        """Pick up an object of the specified color"""
        color = color.upper()
        
        if self.motion_stopped:
            return "Motion is stopped. Use reset_robot to resume."
        
        if self.is_holding_object:
            return f"Already holding {self.last_picked_color} object. Place it first."
        
        if color not in self.latest_coords:
            return f"No {color} object detected. Available: {', '.join(self.latest_coords.keys())}"
        
        # Average multiple coordinate readings
        self.get_logger().info(f"Collecting {self.coordinate_samples} samples for {color}...")
        coord_samples = []
        for i in range(self.coordinate_samples):
            if color in self.latest_coords:
                coord_samples.append(self.latest_coords[color].copy())
            time.sleep(0.1)
        
        if not coord_samples:
            return f"Lost tracking of {color} object"
        
        # Average coordinates
        avg_coords = [
            sum(c[0] for c in coord_samples) / len(coord_samples),
            sum(c[1] for c in coord_samples) / len(coord_samples),
            sum(c[2] for c in coord_samples) / len(coord_samples)
        ]
        
        self.target_coords = avg_coords
        self.get_logger().info(f"Picking {color} at ({avg_coords[0]:.3f}, {avg_coords[1]:.3f}, {avg_coords[2]:.3f})")
        
        try:
            # Calculate positions
            pick_position = [
                self.target_coords[0],
                self.target_coords[1],
                self.target_coords[2] - self.z_offset_above
            ]
            approach_position = [
                pick_position[0],
                pick_position[1],
                pick_position[2] - self.z_approach
            ]
            quat_xyzw = [0.0, 1.0, 0.0, 0.0]
            
            # Execute pick sequence
            self.get_logger().info("Moving to home...")
            self.moveit2.move_to_configuration(self.home_joints)
            self.moveit2.wait_until_executed()
            time.sleep(0.3)
            
            self.get_logger().info("Moving above target...")
            self.moveit2.move_to_pose(position=pick_position, quat_xyzw=quat_xyzw)
            self.moveit2.wait_until_executed()
            time.sleep(0.3)
            
            self.get_logger().info("Opening gripper...")
            self.gripper.open()
            self.gripper.wait_until_executed()
            time.sleep(self.gripper_wait_time)
            
            self.get_logger().info("Descending to grasp...")
            self.moveit2.move_to_pose(
                position=approach_position,
                quat_xyzw=quat_xyzw,
                cartesian=True
            )
            self.moveit2.wait_until_executed()
            time.sleep(self.pre_grasp_wait)
            
            self.get_logger().info("Closing gripper...")
            self.gripper.close()
            self.gripper.wait_until_executed()
            time.sleep(self.post_grasp_wait)
            
            self.get_logger().info("Lifting object...")
            lift_position = [
                approach_position[0],
                approach_position[1],
                approach_position[2] + self.lift_height
            ]
            self.moveit2.move_to_pose(
                position=lift_position,
                quat_xyzw=quat_xyzw,
                cartesian=True
            )
            self.moveit2.wait_until_executed()
            time.sleep(0.3)
            
            self.get_logger().info("High lift for transport...")
            high_lift_position = [
                approach_position[0],
                approach_position[1],
                approach_position[2] + self.safe_lift_height
            ]
            self.moveit2.move_to_pose(
                position=high_lift_position,
                quat_xyzw=quat_xyzw,
                cartesian=True
            )
            self.moveit2.wait_until_executed()
            time.sleep(0.3)
            
            self.get_logger().info("Returning to home with object...")
            self.moveit2.move_to_configuration(self.home_joints)
            self.moveit2.wait_until_executed()
            
            self.is_holding_object = True
            self.last_picked_color = color
            
            return f"Successfully picked up {color} object"
            
        except Exception as e:
            self.get_logger().error(f"Error picking {color}: {e}")
            return f"Failed to pick {color} object: {str(e)}"
    
    def place_object(self) -> str:
        """Place the currently held object at drop location"""
        if self.motion_stopped:
            return "Motion is stopped. Use reset_robot to resume."
        
        if not self.is_holding_object:
            return "Not holding any object. Pick something first."
        
        try:
            self.get_logger().info("Moving to drop location...")
            self.moveit2.move_to_configuration(self.drop_joints)
            self.moveit2.wait_until_executed()
            time.sleep(0.3)
            
            self.get_logger().info("Releasing object...")
            self.gripper.open()
            self.gripper.wait_until_executed()
            time.sleep(self.gripper_wait_time)
            
            self.get_logger().info("Closing gripper...")
            self.gripper.close()
            self.gripper.wait_until_executed()
            time.sleep(0.3)
            
            self.get_logger().info("Returning to start...")
            self.moveit2.move_to_configuration(self.start_joints)
            self.moveit2.wait_until_executed()
            
            placed_color = self.last_picked_color
            self.is_holding_object = False
            self.last_picked_color = None
            
            return f"Successfully placed {placed_color} object in bucket"
            
        except Exception as e:
            self.get_logger().error(f"Error placing object: {e}")
            return f"Failed to place object: {str(e)}"
    
    def go_home(self) -> str:
        """Move to home position"""
        if self.motion_stopped:
            return "Motion is stopped. Use reset_robot to resume."
        
        try:
            self.moveit2.move_to_configuration(self.home_joints)
            self.moveit2.wait_until_executed()
            return "Moved to home position"
        except Exception as e:
            return f"Error: {str(e)}"
    
    def go_start(self) -> str:
        """Move to start position"""
        if self.motion_stopped:
            return "Motion is stopped. Use reset_robot to resume."
        
        try:
            self.moveit2.move_to_configuration(self.start_joints)
            self.moveit2.wait_until_executed()
            return "Moved to start position"
        except Exception as e:
            return f"Error: {str(e)}"
    
    def open_gripper(self) -> str:
        """Open gripper"""
        try:
            self.gripper.open()
            self.gripper.wait_until_executed()
            time.sleep(self.gripper_wait_time)
            return "Gripper opened"
        except Exception as e:
            return f"Error: {str(e)}"
    
    def close_gripper(self) -> str:
        """Close gripper"""
        try:
            self.gripper.close()
            self.gripper.wait_until_executed()
            time.sleep(self.gripper_wait_time)
            return "Gripper closed"
        except Exception as e:
            return f"Error: {str(e)}"
    
    def stop_motion(self) -> str:
        """Emergency stop all motion"""
        self.motion_stopped = True
        # Note: Actual e-stop would need ROS2 control commands
        self.get_logger().warn("EMERGENCY STOP ACTIVATED")
        return "EMERGENCY STOP - All motion halted. Use reset_robot to resume."
    
    def reset(self) -> str:
        """Reset robot to initial state"""
        self.motion_stopped = False
        self.is_holding_object = False
        self.last_picked_color = None
        
        try:
            self.get_logger().info("Resetting robot...")
            self.gripper.open()
            self.gripper.wait_until_executed()
            time.sleep(0.5)
            
            self.moveit2.move_to_configuration(self.start_joints)
            self.moveit2.wait_until_executed()
            
            return "Robot reset to initial state"
        except Exception as e:
            return f"Reset failed: {str(e)}"
    
    def get_status(self) -> str:
        """Get current robot status"""
        status_lines = [
            "ROBOT STATUS",
            f"Motion: {'STOPPED' if self.motion_stopped else 'ACTIVE'}",
            f"Holding object: {'YES - ' + self.last_picked_color if self.is_holding_object else 'NO'}",
            f"Detected objects: {', '.join(self.latest_coords.keys()) if self.latest_coords else 'None'}",
            f"Max velocity: {self.moveit2.max_velocity}",
            f"Max acceleration: {self.moveit2.max_acceleration}"
        ]
        return "\n".join(status_lines)
    
    def list_detected_colors(self) -> str:
        """List detected colors with coordinates"""
        if not self.latest_coords:
            return "No objects detected"
        
        result = "DETECTED OBJECTS:\n"
        for color, coords in self.latest_coords.items():
            result += f"• {color}: ({coords[0]:.3f}, {coords[1]:.3f}, {coords[2]:.3f})\n"
        return result.strip()