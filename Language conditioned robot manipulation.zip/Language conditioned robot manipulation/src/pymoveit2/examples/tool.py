#!/usr/bin/env python3
"""
Robot control tools for pick-and-place operations
"""

from langchain.tools import Tool
from datetime import datetime
from pprint import pformat
import time

# ============================================================================
# GLOBAL ROBOT CONTROLLER REFERENCE
# ============================================================================
_robot_controller = None


def set_robot_controller(controller):
    """Set the robot controller instance for tools to use"""
    global _robot_controller
    _robot_controller = controller


# ============================================================================
# CORE ROBOT FUNCTIONS
# ============================================================================

def pick_red_func(input: str = ""):
    """Pick up the red object"""
    if _robot_controller is None:
        return "Error: Robot controller not initialized"
    return _robot_controller.pick_object("R")


def pick_green_func(input: str = ""):
    """Pick up the green object"""
    if _robot_controller is None:
        return "Error: Robot controller not initialized"
    return _robot_controller.pick_object("G")


def pick_blue_func(input: str = ""):
    """Pick up the blue object"""
    if _robot_controller is None:
        return "Error: Robot controller not initialized"
    return _robot_controller.pick_object("B")


def place_object_func(input: str = ""):
    """Place the currently held object at drop location"""
    if _robot_controller is None:
        return "Error: Robot controller not initialized"
    return _robot_controller.place_object()


def go_home_func(input: str = ""):
    """Move robot to home position"""
    if _robot_controller is None:
        return "Error: Robot controller not initialized"
    return _robot_controller.go_home()


def go_start_func(input: str = ""):
    """Move robot to start position"""
    if _robot_controller is None:
        return "Error: Robot controller not initialized"
    return _robot_controller.go_start()


def open_gripper_func(input: str = ""):
    """Open the robot gripper"""
    if _robot_controller is None:
        return "Error: Robot controller not initialized"
    return _robot_controller.open_gripper()


def close_gripper_func(input: str = ""):
    """Close the robot gripper"""
    if _robot_controller is None:
        return "Error: Robot controller not initialized"
    return _robot_controller.close_gripper()


def stop_robot_func(input: str = ""):
    """Emergency stop - halt all robot motion"""
    if _robot_controller is None:
        return "Error: Robot controller not initialized"
    return _robot_controller.stop_motion()


def check_status_func(input: str = ""):
    """Check robot status and detected objects"""
    if _robot_controller is None:
        return "Error: Robot controller not initialized"
    return _robot_controller.get_status()


def reset_robot_func(input: str = ""):
    """Reset robot to initial state"""
    if _robot_controller is None:
        return "Error: Robot controller not initialized"
    return _robot_controller.reset()


def get_detected_colors_func(input: str = ""):
    """Get list of currently detected colored objects"""
    if _robot_controller is None:
        return "Error: Robot controller not initialized"
    return _robot_controller.list_detected_colors()


def save_robot_log(data: str, filename: str = "robot_operations.log"):
    """Save robot operation log to file with timestamp"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    formatted_text = pformat(f"Timestamp: {timestamp}\n\n{data}\n\n{'='*40}\n\n")
    
    try:
        with open(filename, "a", encoding="utf-8") as f:
            f.write(formatted_text)
        return f"Log successfully saved to {filename}"
    except Exception as e:
        return f"Error saving log: {str(e)}"


# ============================================================================
# LANGCHAIN TOOL WRAPPERS
# ============================================================================

# Pick Operations
pick_red_tool = Tool(
    name="pick_red",
    func=pick_red_func,
    description=(
        "Pick up the RED object. "
        "Use this when user asks to pick, grab, get, or retrieve the red object. "
        "This will move the robot to the red object location, grasp it, and lift it. "
        "No input parameters required."
    )
)

pick_green_tool = Tool(
    name="pick_green",
    func=pick_green_func,
    description=(
        "Pick up the GREEN object. "
        "Use this when user asks to pick, grab, get, or retrieve the green object. "
        "This will move the robot to the green object location, grasp it, and lift it. "
        "No input parameters required."
    )
)

pick_blue_tool = Tool(
    name="pick_blue",
    func=pick_blue_func,
    description=(
        "Pick up the BLUE object. "
        "Use this when user asks to pick, grab, get, or retrieve the blue object. "
        "This will move the robot to the blue object location, grasp it, and lift it. "
        "No input parameters required."
    )
)

# Place Operation
place_object_tool = Tool(
    name="place_object",
    func=place_object_func,
    description=(
        "Place the currently held object at the drop location (bucket). "
        "Use this when user asks to place, drop, put down, or release an object. "
        "Robot must be holding an object before using this tool. "
        "No input parameters required."
    )
)

# Movement Operations
go_home_tool = Tool(
    name="go_home",
    func=go_home_func,
    description=(
        "Move robot arm to its HOME position (safe resting pose). "
        "Use this when user asks to go home, return to home, or reset position. "
        "This is the standard operating position between tasks. "
        "No input parameters required."
    )
)

go_start_tool = Tool(
    name="go_start",
    func=go_start_func,
    description=(
        "Move robot arm to its START position (initial ready pose). "
        "Use this when user asks to go to start, initialize, or prepare for operations. "
        "This is typically used at the beginning of a session. "
        "No input parameters required."
    )
)

# Gripper Operations
open_gripper_tool = Tool(
    name="open_gripper",
    func=open_gripper_func,
    description=(
        "Open the robot gripper to release objects or prepare to grasp. "
        "Use this when user explicitly asks to open the gripper or hand. "
        "No input parameters required."
    )
)

close_gripper_tool = Tool(
    name="close_gripper",
    func=close_gripper_func,
    description=(
        "Close the robot gripper to grasp an object. "
        "Use this when user explicitly asks to close the gripper or hand. "
        "No input parameters required."
    )
)

# Safety and Control
stop_robot_tool = Tool(
    name="stop_robot",
    func=stop_robot_func,
    description=(
        "EMERGENCY STOP - Immediately halt all robot motion. "
        "Use this when user says stop, halt, freeze, or emergency. "
        "This is a safety function to immediately stop the robot. "
        "No input parameters required."
    )
)

reset_robot_tool = Tool(
    name="reset_robot",
    func=reset_robot_func,
    description=(
        "Reset the robot to its initial state and clear any errors. "
        "Use this when user asks to reset, restart, or clear errors. "
        "This returns the robot to start position and resets internal state. "
        "No input parameters required."
    )
)

# Status and Information
check_status_tool = Tool(
    name="check_status",
    func=check_status_func,
    description=(
        "Check the current status of the robot system. "
        "Use this when user asks about robot status, state, or condition. "
        "Returns information about current position, gripper state, and system health. "
        "No input parameters required."
    )
)

get_detected_colors_tool = Tool(
    name="get_detected_colors",
    func=get_detected_colors_func,
    description=(
        "Get list of colored objects currently detected by the vision system. "
        "Use this when user asks what objects are visible, what colors can be seen, "
        "or what is available to pick. "
        "Returns list of detected colors (R, G, B) with their coordinates. "
        "No input parameters required."
    )
)

# Logging
save_log_tool = Tool(
    name="save_robot_log",
    func=save_robot_log,
    description=(
        "Save robot operation logs or status information to a file. "
        "Use this when user asks to save, log, record, or document operations. "
        "Input should be the text data to save as a string. "
        "Example: Save a summary of completed pick-and-place operations."
    )
)


# ============================================================================
# EXPORT ALL TOOLS
# ============================================================================

# All available tools for the agent
all_tools = [
    # Pick operations (specific colors)
    pick_red_tool,
    pick_green_tool,
    pick_blue_tool,
    
    # Place operation
    place_object_tool,
    
    # Movement operations
    go_home_tool,
    go_start_tool,
    
    # Gripper operations
    open_gripper_tool,
    close_gripper_tool,
    
    # Safety and control
    stop_robot_tool,
    reset_robot_tool,
    
    # Status and information
    check_status_tool,
    get_detected_colors_tool,
    
    # Logging
    save_log_tool,
]


# Tool categories for easy reference
pick_tools = [pick_red_tool, pick_green_tool, pick_blue_tool]
movement_tools = [go_home_tool, go_start_tool]
gripper_tools = [open_gripper_tool, close_gripper_tool]
control_tools = [stop_robot_tool, reset_robot_tool]
info_tools = [check_status_tool, get_detected_colors_tool]
utility_tools = [place_object_tool, save_log_tool]